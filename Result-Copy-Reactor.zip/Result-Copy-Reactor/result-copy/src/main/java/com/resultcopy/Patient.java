package com.resultcopy;

public class Patient {
    private int patientId;
    private String firstName;
    private String lastName;
    private String mrn;
    private String fin;
}

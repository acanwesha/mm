package com.resultcopy.rest.api;

import com.resultcopy.rest.api.*;
import io.swagger.model.*;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;

import com.resultcopy.rest.model.PatientResult;

import java.util.Map;
import java.util.List;
import com.resultcopy.rest.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public abstract class PatientResultsApiService {
    public abstract Response patientResultsPatientIdGet(String patientId,SecurityContext securityContext) throws NotFoundException;
}
